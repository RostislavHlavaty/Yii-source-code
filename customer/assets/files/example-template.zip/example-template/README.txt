Template copyright belongs to 99designs.com
It was downloaded from http://99designs.com/customer-blog/99designs-introduces-email-design-category/ 
where it was offered as a free email template.  
Since it comes without any kind of license, i can only assume it's free and can be used/modified/etc.
